package io.github.leonawicz.database.habitdb;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import io.github.leonawicz.database.HabitTrackerContract;

public class HabitTrackerDbHelper extends SQLiteOpenHelper {
    private static final String TEXT_TYPE = " TEXT";
    private static final String INT_TYPE = " INTEGER";
    private static final String SEP = ",";

    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + HabitTrackerContract.HabitEntry.TABLE_NAME + " (" +
                    HabitTrackerContract.HabitEntry._ID + " INTEGER PRIMARY KEY," +
                    HabitTrackerContract.HabitEntry.COLNAME_HABIT + TEXT_TYPE + SEP +
                    HabitTrackerContract.HabitEntry.COLNAME_HABITGRP + TEXT_TYPE + SEP +
                    HabitTrackerContract.HabitEntry.COLNAME_MINUTES + INT_TYPE + " )";

    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + HabitTrackerContract.HabitEntry.TABLE_NAME;

    public HabitTrackerDbHelper(Context context) {
        super(context, HabitTrackerContract.DATABASE_NAME, null, HabitTrackerContract.DATABASE_VERSION);
    }

    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_ENTRIES);
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }

    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }

    public long insertTableRow(String habit, String habitGroup, Integer minutes) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(HabitTrackerContract.HabitEntry.COLNAME_HABIT, habit);
        values.put(HabitTrackerContract.HabitEntry.COLNAME_HABITGRP, habitGroup);
        values.put(HabitTrackerContract.HabitEntry.COLNAME_MINUTES, minutes);

        long newRowId;
        newRowId = db.insert(
                HabitTrackerContract.HabitEntry.TABLE_NAME,
                HabitTrackerContract.HabitEntry.COLNAME_HABIT,
                values);
        return newRowId;
    }

    public String readTableRow(int rowNum) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] proj = {
                HabitTrackerContract.HabitEntry._ID,
                HabitTrackerContract.HabitEntry.COLNAME_HABIT,
                HabitTrackerContract.HabitEntry.COLNAME_HABITGRP,
                HabitTrackerContract.HabitEntry.COLNAME_MINUTES
        };

        Cursor c = db.query(
                HabitTrackerContract.HabitEntry.TABLE_NAME,
                proj, null, null, null, null, null);

        c.moveToPosition(rowNum);
        long itemId = c.getLong(
                c.getColumnIndexOrThrow(HabitTrackerContract.HabitEntry._ID));
        String habitValue = c.getString(
                c.getColumnIndexOrThrow(HabitTrackerContract.HabitEntry.COLNAME_HABIT));
        String habitGroupValue = c.getString(
                c.getColumnIndexOrThrow(HabitTrackerContract.HabitEntry.COLNAME_HABITGRP));
        int minutesValue = c.getInt(
                c.getColumnIndexOrThrow(HabitTrackerContract.HabitEntry.COLNAME_MINUTES));
        return "Row: " + itemId + ", Habit: " + habitValue + ", Group: " + habitGroupValue +
                ", Minutes: " + minutesValue;
    }

    public void deleteTableEntries() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(HabitTrackerContract.HabitEntry.TABLE_NAME, null, null);
        db.close();
    }

    public int updateTableRow(String habit, String habitGroup, Integer minutes, long rowNum) {
        SQLiteDatabase db = this.getReadableDatabase();
        rowNum++;
        ContentValues values = new ContentValues();
        if (habit != null)
            values.put(HabitTrackerContract.HabitEntry.COLNAME_HABIT, habit);
        if (habitGroup != null)
            values.put(HabitTrackerContract.HabitEntry.COLNAME_HABITGRP, habitGroup);
        if (minutes != null)
            values.put(HabitTrackerContract.HabitEntry.COLNAME_MINUTES, minutes);

        String selection = HabitTrackerContract.HabitEntry._ID + " LIKE ?";
        String[] selectionArgs = {rowNum + ""};

        int count = db.update(
                HabitTrackerContract.HabitEntry.TABLE_NAME,
                values,
                selection,
                selectionArgs);
        return count;
    }

    public void deleteDatabase(Context context) {
        context.deleteDatabase(HabitTrackerContract.HabitEntry.TABLE_NAME);
    }

}
