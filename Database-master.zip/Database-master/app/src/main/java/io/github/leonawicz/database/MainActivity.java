package io.github.leonawicz.database;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import io.github.leonawicz.database.habitdb.HabitTrackerDbHelper;

public class MainActivity extends AppCompatActivity {

    private String habit;
    private String habitGroup;
    private int minutes;
    private HabitTrackerDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        habit = "guitar practice";
        habitGroup = "education";
        minutes = 45;
        dbHelper = new HabitTrackerDbHelper(this);

        dbHelper.deleteTableEntries();
        long inserted = dbHelper.insertTableRow(habit, habitGroup, minutes);
        Log.v("MainActivity", "inserted: " + inserted);
        String result = dbHelper.readTableRow(0);
        Log.v("MainActivity", "result: " + result);
        dbHelper.deleteTableEntries();

        inserted = dbHelper.insertTableRow(habit, habitGroup, minutes);
        Log.v("MainActivity", "inserted: " + inserted);
        int id = dbHelper.updateTableRow(null, "Music", null, 0);
        Log.v("MainActivity", "db.update return integer: " + id);
        result = dbHelper.readTableRow(0);
        Log.v("MainActivity", "result: " + result);
        dbHelper.deleteTableEntries();

        inserted = dbHelper.insertTableRow("Baseball", "Sports", 60);
        Log.v("MainActivity", "inserted: " + inserted);
        id = dbHelper.updateTableRow("Dishes", "Cleaning", 30, 0);
        Log.v("MainActivity", "db.update return integer: " + id);
        result = dbHelper.readTableRow(0);
        Log.v("MainActivity", "result: " + result);
        dbHelper.deleteTableEntries();

        dbHelper.deleteDatabase(this);
    }

}
