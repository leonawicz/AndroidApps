package io.github.leonawicz.database;

import android.provider.BaseColumns;

// Contract class describing SQLite database schema
public final class HabitTrackerContract {
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "HabitTracker.db";

    HabitTrackerContract() {
    }

    public static abstract class HabitEntry implements BaseColumns {
        public static final String TABLE_NAME = "entry";
        public static final String COLNAME_HABIT = "habit";
        public static final String COLNAME_HABITGRP = "habitgrp";
        public static final String COLNAME_MINUTES = "minutes";
    }
}
