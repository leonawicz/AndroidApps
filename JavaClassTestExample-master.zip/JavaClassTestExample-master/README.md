# JavaClassTestExample
Example java class with public and private methods and multiple constructors plus a test class to check its operation.
