public class ReportCard {
    private String name;
    private ArrayList<String> courses = new ArrayList<String>();
    private ArrayList<String> grades = new ArrayList<String>();
    private double gpa = 0;

    public ReportCard() {
        this.name = "unknown";
    }

    public ReportCard(ReportCard reportCard) {
        this.name = reportCard.name;
        this.courses = reportCard.courses;
        this.grades = reportCard.grades;
        this.gpa = reportCard.gpa;
    }

    public ReportCard(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    private void calcGpa() {
        int n = grades.size();
        double sum = 0;
        if (n == 0) {
            gpa = 0;
            return;
        }
        for (int i = 0; i < grades.size(); i++) {
            switch (grades.get(i)) {
                case "A":
                    sum += 4;
                    break;
                case "B":
                    sum += 3;
                    break;
                case "C":
                    sum += 2;
                    break;
                case "D":
                    sum += 1;
                    break;
                case "F":
                    break;
                default:
                    break;
            }
        }
        gpa = sum / n;
    }

    public String getGrades() {
        if (courses.size() == 0) return "No grades available for this student.";
        String s = "";
        for (int i = 0; i < courses.size(); i++) {
            s = s + courses.get(i) + ": " + grades.get(i);
            if (i < courses.size() - 1) s = s + ", ";
        }
        return s;
    }

    public String addCourseGrade(String course, String letterGrade) {
        if (letterGrade.matches("[ABCDF]")) {
            courses.add(course);
            grades.add(letterGrade);
            return "Course grade added.";
        } else return letterGrade + " is not a valid grade. Grades must be A, B, C D, or F.";
    }

    public double getGpa() {
        calcGpa();
        return Math.round(gpa*100.0)/100;
    }

    public String toString(){
        String border = "----------------\n";
        String title = border + "Report Card\n";
        String s = "Name: " + name + "\n";
        if(courses.size() == 0) return title + s + "Courses and grades empty.\n" + border;
        return title + s + this.getGrades() + "\nGPA: " + Math.round(this.getGpa()*100.0)/100 + "\n" + border;
    }

}
