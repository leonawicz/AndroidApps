public class ReportCardTest{

     public static void main(String []args){
        ReportCard rc = new ReportCard();
        ReportCard rcCopy = new ReportCard(rc);
        ReportCard rcWithName = new ReportCard("Jane");
        
        System.out.println(rc.toString());
        System.out.println(rcCopy.toString());
        System.out.println(rcWithName.toString());
        
        System.out.println(rc.getName());
        rc.setName("John");
        System.out.println(rc.getName());
        System.out.println(rc.getGrades());
        System.out.println(rc.getGpa());
        
        rc.addCourseGrade("Math", "A");
        rc.addCourseGrade("Art", "B");
        rc.addCourseGrade("History", "F");
        rc.addCourseGrade("Chemistry", "C");
        rc.addCourseGrade("Sociology", "A");
        rc.addCourseGrade("Physics", "B");
        
        System.out.println(rc.getGrades());
        System.out.println(rc.getGpa());
        System.out.println(rc.toString());
        ReportCard rcNewCopy = new ReportCard(rc);
        System.out.println(rcNewCopy.toString());
        System.out.println(rcWithName.toString());
        
     }
     
}
