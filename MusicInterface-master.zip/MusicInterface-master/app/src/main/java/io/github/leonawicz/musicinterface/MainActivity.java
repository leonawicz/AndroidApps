package io.github.leonawicz.musicinterface;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Create listeners for text views.
        TextView playlistView = (TextView) findViewById(R.id.playlists);
        TextView shopView = (TextView) findViewById(R.id.shop);
        TextView nowView = (TextView) findViewById(R.id.now_playing);
        if(playlistView != null) playlistView.setOnClickListener(this);
        if(shopView != null) shopView.setOnClickListener(this);
        if(nowView != null) nowView.setOnClickListener(this);
        // Create listeners for text views. These ones do not function of course.
        TextView song1 = (TextView) findViewById(R.id.s1);
        TextView song2 = (TextView) findViewById(R.id.s2);
        TextView song3 = (TextView) findViewById(R.id.s3);
        TextView song4 = (TextView) findViewById(R.id.s4);
        TextView song5 = (TextView) findViewById(R.id.s5);
        TextView song6 = (TextView) findViewById(R.id.s6);
        TextView song7 = (TextView) findViewById(R.id.s7);
        TextView song8 = (TextView) findViewById(R.id.s8);
        TextView song9 = (TextView) findViewById(R.id.s9);
        TextView song10 = (TextView) findViewById(R.id.s10);

        if (song1 != null) song1.setOnClickListener(this);
        if (song2 != null) song2.setOnClickListener(this);
        if (song3 != null) song3.setOnClickListener(this);
        if (song4 != null) song4.setOnClickListener(this);
        if (song5 != null) song5.setOnClickListener(this);
        if (song6 != null) song6.setOnClickListener(this);
        if (song7 != null) song7.setOnClickListener(this);
        if (song8 != null) song8.setOnClickListener(this);
        if (song9 != null) song9.setOnClickListener(this);
        if (song10 != null) song10.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.playlists:
                Intent intentPlaylist = new Intent(this, PlaylistActivity.class);
                startActivity(intentPlaylist);
                break;
            case R.id.shop:
                Intent intentShop = new Intent(this, ShopActivity.class);
                startActivity(intentShop);
                break;
            case R.id.now_playing:
                Intent intentNow = new Intent(this, NowActivity.class);
                startActivity(intentNow);
                break;
            case R.id.s1:
                //playMedia(R.string.file1);
                //playMedia(R.raw.example_song);
                break;
            case R.id.s2:
                playMedia(R.string.file2);
                break;
            case R.id.s3:
                playMedia(R.string.file3);
                break;
            case R.id.s4:
                playMedia(R.string.file4);
                break;
            case R.id.s5:
                playMedia(R.string.file5);
                break;
            case R.id.s6:
                playMedia(R.string.file6);
                break;
            case R.id.s7:
                playMedia(R.string.file7);
                break;
            case R.id.s8:
                playMedia(R.string.file8);
                break;
            case R.id.s9:
                playMedia(R.string.file9);
                break;
            case R.id.s10:
                playMedia(R.string.file10);
                break;
            default:
                break;
        }
    }

    public void playMedia(int Rid) {
        Uri uri = Uri.parse(getText(Rid).toString());
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(uri);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

}