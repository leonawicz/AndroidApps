package io.github.leonawicz.courtcounter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int scoreA = 0;
    int scoreB = 0;
    // int scoreA, scoreB = 0; // alternative declaration

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * Displays the given score for Team A.
     */
    public void displayForTeamA(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_a_score);
        scoreView.setText(String.valueOf(score));
    }

    /**
     * Displays the given score for Team B.
     */
    public void displayForTeamB(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_b_score);
        scoreView.setText(String.valueOf(score));
    }

    /**
     * methods for adding to scores
     */
    public void add3ToTeamA(View view) {
        scoreA += 3;
        displayForTeamA(scoreA);
    }

    public void add2ToTeamA(View view) {
        scoreA += 2;
        displayForTeamA(scoreA);
    }

    public void add1ToTeamA(View view) {
        scoreA++;
        displayForTeamA(scoreA);

    }

    public void add3ToTeamB(View view) {
        scoreB += 3;
        displayForTeamB(scoreB);
    }

    public void add2ToTeamB(View view) {
        scoreB += 2;
        displayForTeamB(scoreB);
    }

    public void add1ToTeamB(View view) {
        scoreB++;
        displayForTeamB(scoreB);

    }

    /**
     * method to reset score
     */
    public void resetScore(View view) {
        scoreA = scoreB = 0;
        displayForTeamA(scoreA);
        displayForTeamB(scoreB);

    }
}