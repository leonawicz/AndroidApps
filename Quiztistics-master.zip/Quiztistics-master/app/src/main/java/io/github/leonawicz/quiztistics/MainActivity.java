package io.github.leonawicz.quiztistics;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void getScore(View v) {
        int score = 0;

        // Question 1 radio button can have only one correct response
        RadioButton q1a1 = (RadioButton) findViewById(R.id.q1_a1);
        if (q1a1.isChecked()) score++;

        // Question 2 checkboxes require four specific checked boxes and two unchecked
        // This code seems too repetetive
        CheckBox q2a1 = (CheckBox) findViewById(R.id.q2_a1);
        CheckBox q2a2 = (CheckBox) findViewById(R.id.q2_a2);
        CheckBox q2a3 = (CheckBox) findViewById(R.id.q2_a3);
        CheckBox q2a4 = (CheckBox) findViewById(R.id.q2_a4);
        CheckBox q2a5 = (CheckBox) findViewById(R.id.q2_a5);
        CheckBox q2a6 = (CheckBox) findViewById(R.id.q2_a6);
        if (q2a1.isChecked() && q2a2.isChecked() && q2a3.isChecked() &&
                !q2a4.isChecked() && !q2a5.isChecked() && q2a6.isChecked())
            score++;

        // Question 3 requires correct text string be typed, case insensitive
        EditText text = (EditText) findViewById(R.id.q3_text);
        String str = text.getText().toString();
        if (str.equalsIgnoreCase(getString(R.string.q3_a1))) score++;

        // Question 4 radio button can have only one correct response
        RadioButton q4a2 = (RadioButton) findViewById(R.id.q4_a2);
        if (q4a2.isChecked()) score++;

        // Question 5 radio button can have only one correct response
        RadioButton q5a4 = (RadioButton) findViewById(R.id.q5_a4);
        if (q5a4.isChecked()) score++;

        String strScore;
        if (score == 5) {
            strScore = "Great job! Your score: " + score + " of 5!";
        } else {
            strScore = "Your score: " + score + " of 5. Please try again.";
        }
        Toast toast = Toast.makeText(getApplicationContext(), strScore, Toast.LENGTH_LONG);
        toast.show();
    }
}
