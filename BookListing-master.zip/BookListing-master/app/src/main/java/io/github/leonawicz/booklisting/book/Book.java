package io.github.leonawicz.booklisting.book;

public class Book {
    private String title;
    private String authors;
    private String publisher;
    private String date;
    private String description;

    public Book(String title, String authors, String publisher, String date, String description) {
        this.title = title;
        this.authors = authors;
        this.publisher = publisher;
        this.date = date;
        this.description = description;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthors() {
        return authors;
    }

    public String getPublisher() {
        return publisher;
    }

    public String getDate() {
        return date;
    }

    public String getDescription() {
        return description;
    }

    public String toString(){
        return "title: " + title + "\nAuthors: " + authors + "\npublisher: " + publisher +
                "\nPublished date: " + date +"\nDescription" + description + "\n";
    }
}
