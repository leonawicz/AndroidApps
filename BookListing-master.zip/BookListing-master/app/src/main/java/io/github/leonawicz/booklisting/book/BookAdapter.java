package io.github.leonawicz.booklisting.book;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.ArrayList;
import io.github.leonawicz.booklisting.R;

/**
 * Created by Matt on 7/17/2016.
 */
public class BookAdapter extends ArrayAdapter<Book> {

    public BookAdapter(Activity context, ArrayList<Book> books) {
        super(context, 0, books);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View listItemView = convertView;
        if(listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_item, parent, false);
        }

        Book books = getItem(position);
        TextView title = (TextView) listItemView.findViewById(R.id.title);
        title.setText(books.getTitle());
        TextView authors = (TextView) listItemView.findViewById(R.id.authors);
        authors.setText(books.getAuthors());
        TextView publisher = (TextView) listItemView.findViewById(R.id.publisher);
        publisher.setText(books.getPublisher());
        TextView date = (TextView) listItemView.findViewById(R.id.date);
        date.setText(books.getDate());
        TextView description = (TextView) listItemView.findViewById(R.id.description);
        description.setText(books.getDescription());
        return listItemView;
    }
}

