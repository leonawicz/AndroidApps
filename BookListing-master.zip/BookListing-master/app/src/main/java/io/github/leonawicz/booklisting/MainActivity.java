package io.github.leonawicz.booklisting;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import io.github.leonawicz.booklisting.book.Book;
import io.github.leonawicz.booklisting.book.BookAdapter;

public class MainActivity extends AppCompatActivity {

    private static final String DEBUG_TAG = "HttpExample";
    private EditText keywords;
    private Button btn;
    private ListView list;
    public static final String EMPTY_BOOK_FIELD = "not available";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        keywords = (EditText) findViewById(R.id.input_keywords);
        btn = (Button) findViewById(R.id.btn);
        list = (ListView) findViewById(R.id.list);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String keywordsStr = keywords.getText().toString()
                        .replace("%", "%25")
                        .replace(" ", "%20");

                String s = "https://www.googleapis.com/books/v1/volumes?q=" +
                        keywordsStr + "&maxResults=10";
                ConnectivityManager connMgr = (ConnectivityManager)
                        getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo netInfo = connMgr.getActiveNetworkInfo();
                if (netInfo != null && netInfo.isConnected()) {
                    new DownloadJsonTask().execute(s);
                } else {
                    Toast.makeText(MainActivity.this, R.string.no_net, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private class DownloadJsonTask extends AsyncTask<String, Void, String> {

        private ArrayList<Book> books = new ArrayList<>();

        @Override
        protected String doInBackground(String... urls) {
            try {
                return downloadUrl(urls[0]);
            } catch (IOException e) {
                return "Cannot download JSON data. Check your url.";
            }
        }

        @Override
        protected void onPostExecute(String result) {
            Book book;
            try {
                JSONObject jsonRoot = new JSONObject(result);
                JSONArray jsonArray = jsonRoot.optJSONArray("items");
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObj = jsonArray.getJSONObject(i).getJSONObject("volumeInfo");
                    String title = jsonObj.optString("title");
                    title = isAvail(title, getString(R.string.prefix_no_title));
                    String authors = jsonObj.optString("authors");
                    authors = isAvail(authors, getString(R.string.prefix_no_authors));
                    authors = authors.replaceAll("\\[|\\]|\"", ""). replace(",", ", ");
                    String publisher = jsonObj.optString("publisher");
                    publisher = isAvail(publisher, getString(R.string.prefix_no_publisher));
                    String pubDate = jsonObj.optString("publishedDate");
                    pubDate = isAvail(pubDate, getString(R.string.prefix_no_date));
                    String description = jsonObj.optString("description");
                    description = isAvail(description, getString(R.string.prefix_no_description));
                    book = new Book(title, authors, publisher, pubDate, description);
                    books.add(book);
                }
                BookAdapter adapter = new BookAdapter(MainActivity.this, books);
                list.setAdapter(adapter);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        private String isAvail(String s, String field){
            if(s == null || s.equals("")) return field + " " + EMPTY_BOOK_FIELD;
            return s;
        }
    }

    private String downloadUrl(String urlString) throws IOException {
        InputStream inStream = null;

        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(10000);
            conn.setConnectTimeout(15000);
            conn.setRequestMethod("GET");
            conn.setDoInput(true);
            conn.connect();
            int response = conn.getResponseCode();
            Log.d(DEBUG_TAG, "The response is: " + response);
            inStream = conn.getInputStream();
            return readStream(inStream);
        } finally {
            if (inStream != null) {
                inStream.close();
            }
        }
    }

    public String readStream(InputStream stream) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
        StringBuilder lines = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            lines.append(line);
        }
        return lines.toString();
    }

}
